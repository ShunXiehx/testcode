package com.example.demotest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Test {
    public static void main(String[] args) {
        // Given an string representing a paragraph,
        // find the max occurance of a character in the string.
        String s = "Hello, Good morning";
        System.out.println("the max occur charter is: " + findMaxCharter(s));
        char maxCharter = findMaxCharter(s);
        System.out.println("the max occur charter number is: "
                + findCountNumber(s, maxCharter));
        Map<Character, Integer> maxCharNum = findMaxCharNum(s);
        Iterator<Map.Entry<Character, Integer>> iterator = maxCharNum.entrySet().iterator();
        if (iterator.hasNext()) {
            Map.Entry<Character, Integer> next = iterator.next();
            System.out.println("the charter is " + next.getKey());
            System.out.println("the charter occur number is " + next.getValue());
        }
    }
    public static char findMaxCharter(String s) {
        Map<Character, Integer> charCount = new HashMap<>();
        char[] chars = s.toCharArray();
        for (char c: chars) {
            if (Character.isLetter(c)) {
                charCount.put(c, charCount.getOrDefault(c,0) + 1);
            }
        }
        char maxChar = ' ';
        int maxCount = 0;
        for (Map.Entry<Character, Integer> entry : charCount.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxChar = entry.getKey();
                maxCount = entry.getValue();
            }
        }
        return maxChar;
    }

    public static int findCountNumber(String s, char charter) {
        int count = 0;
        char[] chars = s.toCharArray();
        for (char c : chars) {
            if (c == charter) {
                count++;
            }
        }
        return count;
    }

    public static Map<Character, Integer> findMaxCharNum(String s) {
        Map<Character, Integer> charCount = new HashMap<>();
        char[] chars = s.toCharArray();
        for (char c: chars) {
            if (Character.isLetter(c)) {
                charCount.put(c, charCount.getOrDefault(c,0) + 1);
            }
        }
        char maxChar = ' ';
        int maxCount = 0;
        for (Map.Entry<Character, Integer> entry : charCount.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxChar = entry.getKey();
                maxCount = entry.getValue();
            }
        }
        System.out.println(maxChar + "---" + maxCount);
        charCount.put(maxChar, maxCount);
        Map<Character, Integer> resultMap = new HashMap<>();
        resultMap.put(maxChar, maxCount);
        return resultMap;
    }
}
