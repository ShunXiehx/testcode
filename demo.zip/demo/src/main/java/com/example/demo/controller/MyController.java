package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@ResponseBody
@RestController("/sms")
public class MyController {

    @RequestMapping(value = "/name", method = RequestMethod.GET)
    public String myTest(){
        return "张三里斯王武";
    }

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 单发短信测试
     * @Author: Sans
     * @CreateTime: 2019/4/2 10:06
     */
    @RequestMapping(value = "/sendsmsTest",method = RequestMethod.GET)
    public String sendsmsTest(){
        //单发短信API
        String url = "https://open.ucpaas.com/ol/sms/sendsms";

        return "";
    }
}
