package com.example.demo.nacos;


import com.alibaba.nacos.api.NacosFactory;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.exception.NacosException;

import java.util.Properties;

public class NacosSimpleDemo {
    public static void main(String[] args) throws NacosException {
        String dataId = "dev.yml";
        String group = "DEFAULT_GROUP";
        String url = "127.0.0.1:8848";
        String nameSpace = "b1c0834d-eec4-4ae7-84aa-5024538ebb28";
        Properties properties = new Properties();
        properties.put("serverAddr", url);
        properties.put("namespace", nameSpace);
        ConfigService configService = NacosFactory.createConfigService(properties);
        String config = configService.getConfig(dataId, group, 8000);
        System.out.println(config);

    }
}
